package com.spot.alert.adapter;

public interface ClickListener {
    void click(Object obj);

}